// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep, here lays the structure for each level of the game
// ----------------------------------------------------------------------------

#include "ThreedLevel.h"

// ----------------------------------------------------------------------------
ThreedLevel::ThreedLevel( )
{
}

// ----------------------------------------------------------------------------
ThreedLevel::~ThreedLevel( )
{
}

// ----------------------------------------------------------------------------
void ThreedLevel::setId( int id )
{
    this->id = id;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setScore( int score )
{
    this->score = score;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setDiff( int diff )
{
    this->diff = diff;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setColorF( std::vector< float > colorF )
{
    this->colorF = colorF;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setSizeL( std::vector< float > sizeL )
{
    this->sizeL = sizeL;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setPosSnake( std::vector < std::vector < float > > posSnake )
{
    this->posSnake = posSnake;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setPosFruits( std::vector < std::vector < float > > posFruits )
{
    this->posFruits = posFruits;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setObstacles( std::vector < std::vector < float > > obstacles )
{
    this->obstacles = obstacles;
}

// ----------------------------------------------------------------------------
int ThreedLevel::getId( )
{
    return this->id;
}

// ----------------------------------------------------------------------------
int ThreedLevel::getScore( )
{
    return this->score;
}

// ----------------------------------------------------------------------------
int ThreedLevel::getDiff( )
{
    return this->diff;
}

// ----------------------------------------------------------------------------
std::vector < float > ThreedLevel::getColorF( )
{
    return this->colorF;
}

// ----------------------------------------------------------------------------
std::vector < float > ThreedLevel::getSizeL( )
{
    return this->sizeL;
}

// ----------------------------------------------------------------------------
std::vector < std::vector < float > > ThreedLevel::getPosSnake( )
{
    return this->posSnake;
}

// ----------------------------------------------------------------------------
std::vector < std::vector < float > > ThreedLevel::getPosFruits( )
{
    return this->posFruits;
}

// ----------------------------------------------------------------------------
std::vector < std::vector < float > > ThreedLevel::getObstacles( )
{
    return this->obstacles;
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyOne( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    std::vector < float > aux;
    if( ( temp[ 0 ] + 1 ) < sizeL[ 0 ] )
    {
        this->posSnake.pop_back( );
        temp[ 0 ] += 1;
        for( int i = 1 ; i < this->posSnake.size( ) ; ++i )
        {
            aux = this->posSnake[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ]  )
            {
                return 1;
            }
        }
        for( int i = 0 ; i < this->obstacles.size( ) ; ++i )
        {
            aux = this->obstacles[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ] )
            {
                return 1;
            }
        }
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyTwo( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    std::vector < float > aux;
    if( ( temp[ 0 ] - 1 ) > 0 )
    {
        this->posSnake.pop_back( );
        temp[ 0 ] -= 1;
        for( int i = 1 ; i < this->posSnake.size( ) ; ++i )
        {
            aux = this->posSnake[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ]  )
            {
                return 1;
            }
        }
        for( int i = 0 ; i < this->obstacles.size( ) ; ++i )
        {
            aux = this->obstacles[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ] )
            {
                return 1;
            }
        }
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyThree( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    std::vector < float > aux;
    if( ( temp[ 2 ] + 1 ) < sizeL[ 0 ] )
    {
        this->posSnake.pop_back( );
        temp[ 2 ] += 1;
        for( int i = 1 ; i < this->posSnake.size( ) ; ++i )
        {
            aux = this->posSnake[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ]  )
            {
                return 1;
            }
        }
        for( int i = 0 ; i < this->obstacles.size( ) ; ++i )
        {
            aux = this->obstacles[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ] )
            {
                return 1;
            }
        }
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyFour( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    std::vector < float > aux;
    if( ( temp[ 2 ] - 1 ) > 0 )
    {
        this->posSnake.pop_back( );
        temp[ 2 ] -= 1;
        for( int i = 1 ; i < this->posSnake.size( ) ; ++i )
        {
            aux = this->posSnake[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ]  )
            {
                return 1;
            }
        }
        for( int i = 0 ; i < this->obstacles.size( ) ; ++i )
        {
            aux = this->obstacles[ i ];
            if( temp[ 0 ] == aux[ 0 ] && temp[ 1 ] == aux[ 1 ] && temp[ 2 ] == aux[ 2 ] )
            {
                return 1;
            }
        }
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyOneI( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 0 ] + 1 ) < sizeL[ 0 ] )
    {
        temp[ 0 ] += 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyTwoI( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 0 ] - 1 ) > 0 )
    {
        temp[ 0 ] -= 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyThreeI( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 2 ] + 1 ) < sizeL[ 0 ] )
    {
        temp[ 2 ] += 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyFourI( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 2 ] - 1 ) > 0 )
    {
        temp[ 2 ] -= 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
