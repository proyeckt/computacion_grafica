// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep, here lays the structure for each level of the game
// ----------------------------------------------------------------------------

#ifndef __ThreedLevel__h__
#define __ThreedLevel__h__

#include <GL/glut.h>
#include <bits/stdc++.h>

// ----------------------------------------------------------------------------
class ThreedLevel
{
public:
    ThreedLevel( );
    virtual ~ThreedLevel( );

    void setId( int id );
    void setScore( int score );
    void setDiff( int diff );
    void setColorF( std::vector< float > colorF );
    void setSizeL( std::vector< float > sizeL );
    void setPosSnake( std::vector < std::vector < float > > posSnake );
    void setPosFruits( std::vector < std::vector < float > > posFruits );
    void setObstacles( std::vector < std::vector < float > > obstacles );

    int getId( );
    int getScore( );
    int getDiff( );
    std::vector < float > getColorF( );
    std::vector < float > getSizeL( );
    std::vector < std::vector < float > > getPosSnake( );
    std::vector < std::vector < float > > getPosFruits( );
    std::vector < std::vector < float > > getObstacles( );

    int modifyOne( );
    int modifyTwo( );
    int modifyThree( );
    int modifyFour( );

    int modifyOneI( );
    int modifyTwoI( );
    int modifyThreeI( );
    int modifyFourI( );


protected:
    int id;
    int score;
    int diff;
    std::vector < float > colorF;
    std::vector < float > sizeL;
    std::vector < std::vector < float > > posSnake;
    std::vector < std::vector < float > > posFruits;
    std::vector < std::vector < float > > obstacles;

};

#endif
